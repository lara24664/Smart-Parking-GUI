
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Lara
 */
public class Reservation extends javax.swing.JFrame {

    Connection con;
    static String username;
    DefaultTableModel model, model2;
    int p = 5;
    boolean b;

    /**
     * Creates new form Reservation
     */
    public Reservation() {
        initComponents();
        Reservation.username = LoginPark.usern;
        getToCombo();
        this.user.setText(username);
        this.user1.setText(username);
        setPanelVeh();
        getDate();
        //  this.jLabel2.setText(new Date());

        this.setLocationRelativeTo(null);
        ImageIcon im4 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("15-512.png")));
        Image img9 = im4.getImage();
        Image img10 = img9.getScaledInstance(jLabel12.getWidth(), jLabel12.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon s = new ImageIcon(img10);
        jLabel12.setIcon(s);
        
          model2 = (DefaultTableModel) jTable2.getModel();
        if (user1.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "you don't have a user name");
        } else {
            con = null;
            String url;
            url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection(url);
                if (con != null) {
                    String q = "Select Parking.Name,Reservation.NumEtage,Reservation.NumPlace,Reservation.TimeDeb,Reservation.Duration From Reservation,Parking,Utilisateur where Reservation.Idparking=Parking.Idparking and Utilisateur.IdUtilisateur=Reservation.IdUtilisateur and Utilisateur.Username='" + user1.getText() + "'";
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(q);
                    while (rs.next()) {
                        model2.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getInt(3), rs.getTime(4), rs.getInt(5)});
                    }
                }

            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void setPanelVeh() {
        String NameUti;
        con = null;
        String url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";
        if (user.getText().equals("null")) {
            JOptionPane.showMessageDialog(this, "you don't have a username");

        } else {
            NameUti = user.getText();
            try {

                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection(url);
                if (con != null) {
                    String q = "Select Utilisateur.IdUtilisateur from Utilisateur,Vehicule where Utilisateur.IdUtilisateur=Vehicule.IdUtlisateur and Utilisateur.Username='" + NameUti + "'";
                    Statement r = con.createStatement();
                    ResultSet res = r.executeQuery(q);
                    if (res.next()) {

                        jPanel8.setVisible(false);
                        b = false;

                    } else {
                        jPanel8.setVisible(true);
                        b = true;
                    }

                }
            } catch (ClassNotFoundException | SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }
    }

    public void getToCombo() {
        con = null;
        String url, m;
        url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";
        int x;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(url);
            if (con != null) {
                Statement st = con.createStatement();
                String q5 = "Select DISTINCT(Name) from Parking";
                ResultSet ss = st.executeQuery(q5);
                while (ss.next()) {
                    m = ss.getString(1);
                    jComboBox5.addItem(m);
                    NamePark.addItem(m);

                }

            }
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(this,ex.getMessage());
        }

    }
    public void getDate()
    {
        Calendar c1=Calendar.getInstance();
        String Date=""+(c1.get(Calendar.MONTH)+1)+"/"+c1.get(Calendar.DATE)+"/"+c1.get(Calendar.YEAR)+"";
        jLabel5.setText(Date);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        timeOfDay1 = new org.joda.time.TimeOfDay();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jPanel7 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        NamePark = new javax.swing.JComboBox<>();
        NumEtage = new javax.swing.JComboBox<>();
        NumPlace = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        TimeFin = new javax.swing.JTextField();
        TimeDEB = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        NumVeh = new javax.swing.JTextField();
        NomVeh = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 600));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(255, 221, 141));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Reservation un Place");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 153, 0));
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 0));
        jLabel3.setText("Name Parking:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 102, 0));
        jLabel4.setText("Etage of parking:");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numero Place", "Description"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setGridColor(new java.awt.Color(255, 153, 0));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(255, 153, 0));
        jButton1.setText("Show Information");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jComboBox5.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox5ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(142, 142, 142))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 615, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(29, 29, 29)
                                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(213, 213, 213)
                        .addComponent(jButton1)))
                .addContainerGap(127, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jButton1)))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Show Place in parking", jPanel5);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 102, 0));
        jLabel19.setText("Username:");

        user1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        user1.setForeground(new java.awt.Color(102, 102, 102));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom Parking", "Num Etage", "Num place", "Time debut", "Duration"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable2);

        jButton5.setText("Delete");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addComponent(jButton5))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(33, 33, 33)
                                .addComponent(user1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel19)
                    .addComponent(user1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jButton5)
                .addGap(150, 150, 150))
        );

        jTabbedPane1.addTab("Show et supprimer une reservation ", jPanel7);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 102, 0));
        jLabel6.setText("Num Place:");
        jPanel6.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 153, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 102, 0));
        jLabel7.setText("Num Etage:");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 105, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 102, 0));
        jLabel9.setText("Time debut:");
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 218, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 102, 0));
        jLabel10.setText("heure");
        jPanel6.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, -1, -1));

        jButton2.setText(" Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 102, 0));
        jLabel13.setText("Username:");
        jPanel6.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 21, -1, -1));

        NamePark.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                NameParkItemStateChanged(evt);
            }
        });
        jPanel6.add(NamePark, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 69, -1, -1));

        jPanel6.add(NumEtage, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 113, -1, -1));

        jPanel6.add(NumPlace, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 161, -1, -1));

        user.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        user.setForeground(new java.awt.Color(102, 102, 102));
        jPanel6.add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 21, 113, 24));

        jButton3.setText("Print");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, -1, -1));
        jPanel6.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 21, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 102, 0));
        jLabel16.setText("Name of Parking:");
        jPanel6.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 69, -1, -1));

        TimeFin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        TimeFin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimeFinActionPerformed(evt);
            }
        });
        jPanel6.add(TimeFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 70, -1));

        TimeDEB.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        TimeDEB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimeDEBActionPerformed(evt);
            }
        });
        jPanel6.add(TimeDEB, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, 70, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 102, 0));
        jLabel18.setText("Duration:");
        jPanel6.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 260, -1, -1));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 102, 0));
        jLabel8.setText("Num Vehicule:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 102, 0));
        jLabel17.setText("Nom du vehicule:");

        NumVeh.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        NumVeh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumVehActionPerformed(evt);
            }
        });

        NomVeh.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        NomVeh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomVehActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 102, 0));
        jLabel15.setText("Type :");

        jRadioButton3.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setText("Voiture");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        jRadioButton2.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("Moto");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(NomVeh, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(NumVeh, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel15)
                .addGap(28, 28, 28)
                .addComponent(jRadioButton3)
                .addGap(33, 33, 33)
                .addComponent(jRadioButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel8))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(NumVeh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(NomVeh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jRadioButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton2))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jPanel6.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 430, 190));

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane4.setViewportView(jTextArea2);

        jPanel6.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 360, 190));

        jTabbedPane1.addTab("Revervation place", jPanel6);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(2479, 2479, 2479))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(155, 0, 850, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        con = null;
        String occ = "occupee";
        String NameUti = user.getText();
        String NamePa = (String) NamePark.getSelectedItem();
        String NuEtage = (String) NumEtage.getSelectedItem();
        String NUmPlace = (String) NumPlace.getSelectedItem();
        int nump = Integer.parseInt(NUmPlace);
        String timdeb = TimeDEB.getText();
        String timfi = TimeFin.getText();
        int dur = Integer.parseInt(timfi);

        String NumVe;
        String NomVe;
        int Idpar = 0, IdUti = 0;
        String url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

        if (NamePark.getSelectedItem() == null || NumEtage.getSelectedItem() == null || NumPlace.getSelectedItem() == null || TimeDEB.getText().isEmpty() || TimeFin.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error you not enter one of the information");

        } else {

            try {

                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection(url);
                if (con != null) {
                    String q123 = "Select Utilisateur.IdUtilisateur from Utilisateur,Reservation ,Parking where Utilisateur.IdUtilisateur=Reservation.IdUtilisateur and Parking.Idparking=Reservation.Idparking and Username='" + NameUti + "' and Parking.Name='" + NamePa + "'";
                    Statement rs = con.createStatement();
                    if (rs.executeQuery(q123).next()) {
                        JOptionPane.showMessageDialog(this, "you are deja reserver dans ce parking");

                    } else {
                        String q11 = " Select Idparking From Parking Where Name='" + NamePa + "'";

                        ResultSet ss = rs.executeQuery(q11);
                        if (ss.next()) {
                            Idpar = ss.getInt(1);
                        }
                        String q12 = " Select IdUtilisateur From Utilisateur Where Username='" + NameUti + "'";
                        ResultSet s2 = rs.executeQuery(q12);
                        if (s2.next()) {
                            IdUti = s2.getInt(1);
                        }
                        int prix = Integer.parseInt(TimeFin.getText()) * p;
                        String q1 = "Insert into Reservation Values(" + Idpar + "," + IdUti + ",'" + NuEtage + "'," + nump + ",'" + timdeb + "'," + prix + "," + dur + ")";
                        if (b = true) {
                            NumVe = NumVeh.getText();
                            NomVe = NomVeh.getText();
                            if (NomVeh.getText().isEmpty() || NumVeh.getText().isEmpty() || !jRadioButton2.isSelected() && !jRadioButton3.isSelected()) {
                                JOptionPane.showMessageDialog(this, "you not enter the option of your car");

                            } else {
                                if (jRadioButton2.isSelected()) {
                                    String q3 = "Insert into Vehicule Values(" + IdUti + ",'" + NumVe + "','" + NomVe + "','" + jRadioButton2.getText() + "')";
                                    rs.executeUpdate(q3);
                                } else {
                                    String q4 = "Insert into Vehicule Values(" + IdUti + ",'" + NumVe + "','" + NomVe + "','" + jRadioButton3.getText() + "')";
                                    rs.executeUpdate(q4);
                                }
                            }
                        }
                        else{
                        JOptionPane.showConfirmDialog(this,"You are deja entrer les infos des voitures");
                        }
                        String q2 = "Update Place set DescripPlace='" + occ + "' Where numPlace=" + nump + " and numEtage='" + NuEtage + "' And Idparking=" + Idpar + "";
                        rs.executeUpdate(q1);
                        rs.executeUpdate(q2);
                        JOptionPane.showMessageDialog(this, "Reservation donne");
                        NumPlace.removeItem(NUmPlace);
                        String Querr = "Select Prenom,nom from Utilisateur where Username='" + user.getText() + "'";
                        ResultSet rrr = rs.executeQuery(Querr);
                        if(rrr.next())
                        {
                        String n ="";
                        
                        n+= "Prenom:" + rrr.getString(1) + "\n";
                        n+= "nom:" + rrr.getString(2) + "\n";
                        n+= "Name Parking:" + NamePa + "\n";
                        n+= "Num Etage:" + NuEtage + "\n";
                        n+= "Num Place:" + nump + "\n";
                        n+= "Time Debut:" + timdeb + "\n";
                        n+= "Duration:" + dur + "\n";
                        n+= "Prix:" + prix + "\n";
                       
                        jTextArea2.setText(n);
                        }
                    }
                }
            } catch (ClassNotFoundException | SQLException ex) {
                System.out.println(ex.getMessage());
            }

        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        HomePage home = new HomePage();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       jTable1.removeAll();
        if (jComboBox5.getSelectedIndex() == -1 || jComboBox6.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this, "Error you don't Select 1 of option");
        } else {
            String name = (String) jComboBox5.getSelectedItem();
            String nEtage = (String) jComboBox6.getSelectedItem();
            con = null;
            String url;
            url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection(url);
                if (con != null) {
                    model = (DefaultTableModel) jTable1.getModel();
                    Statement st = con.createStatement();
                    String q = "Select numPlace,DescripPlace from Parking,Place where Name='" + name + "' and numEtage='" + nEtage + "' ";
                    ResultSet rs = st.executeQuery(q);
                    while (rs.next()) {
                        model.addRow(new Object[]{rs.getInt(1), rs.getString(2)});

                    }

                }

            } catch (ClassNotFoundException | SQLException ex) {
                // Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox5ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox5ItemStateChanged

        String item = (String) jComboBox5.getSelectedItem();
        con = null;
        String url;
        url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(url);
            if (con != null) {
                Statement st = con.createStatement();
                String q09 = "Select nbEtage from Parking Where Name='" + item + "'";
                ResultSet ss = st.executeQuery(q09);
                if (ss.next()) {
                    jComboBox6.removeAllItems();
                    int j = ss.getInt(1);
                    for (int i = 1; i <= j; i++) {
                        jComboBox6.addItem("G" + i);

                    }

                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jComboBox5ItemStateChanged

    private void NameParkItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_NameParkItemStateChanged
        String item = (String) NamePark.getSelectedItem();
        con = null;
        String url;
        url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(url);
            if (con != null) {
                Statement st = con.createStatement();
                String q09 = "Select nbEtage from Parking Where Name='" + item + "'";
                ResultSet ss = st.executeQuery(q09);
                if (ss.next()) {
                    NumEtage.removeAllItems();
                    int j = ss.getInt(1);
                    for (int i = 1; i <= j; i++) {
                        NumEtage.addItem("G" + i);

                    }

                }
                String f = "free";
                String q21 = "Select Place.numPlace from Parking,Place Where Parking.Idparking = Place.Idparking AND Parking.Name = '" + item + "' AND Place.DescripPlace = '" + f + "'";
                ResultSet s2 = st.executeQuery(q21);
                NumPlace.removeAllItems();
                while (s2.next()) {

                    NumPlace.addItem(String.valueOf(s2.getInt(1)));

                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());
// Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_NameParkItemStateChanged

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void NomVehActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomVehActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NomVehActionPerformed

    private void NumVehActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumVehActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumVehActionPerformed

    private void TimeDEBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimeDEBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TimeDEBActionPerformed

    private void TimeFinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimeFinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TimeFinActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            boolean complete = jTextArea2.print();
            if (complete) {
                JOptionPane.showMessageDialog(this, "The print done");
            } else {
                JOptionPane.showMessageDialog(this, "The printer not existe");
            }
        } catch (PrinterException ex) {
            Logger.getLogger(Reservation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (jTable2.getSelectedRow()==-1) {
            JOptionPane.showMessageDialog(this, "you must selected the colomn from the table");
        } else {
            int idU = 0,idP = 0;
            int i = jTable2.getSelectedRow();
            DefaultTableModel mo = (DefaultTableModel) jTable2.getModel();
            String np = (String) mo.getValueAt(i, 0);
            String n = (String) mo.getValueAt(i, 1);
            int numP = (int) mo.getValueAt(i, 2);
            con = null;
            String url;
            url = "jdbc:sqlserver://localhost;databaseName=GuiProjet;integratedSecurity=true;";

            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection(url);
                if (con != null) 
                {
                        String q1="Select IdParking from Parking where Name='"+np+"'";
                        Statement st = con.createStatement();
                        ResultSet r1=st.executeQuery(q1);
                        if(r1.next())
                        {
                            idP=r1.getInt(1);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(this,"Error Parking");
                        }
                         String q12="Select IdUtilisateur from Utilisateur where Username='"+user1.getText()+"'";
                         ResultSet r2=st.executeQuery(q12);
                         if(r2.next())
                         {
                             idU=r2.getInt(1);
                         }
                         else{
                             JOptionPane.showMessageDialog(this,"Error utilisateur");
                         }
                         String f="free";
                         String q3="Delete from Reservation Where Idparking="+idP+" And IdUtilisateur="+idU+" And numEtage='"+n+"' and numPlace="+numP+" ";
                        st.executeUpdate(q3);
                        mo.removeRow(i);
                        JOptionPane.showMessageDialog(this,"Reservation delete..");
                        String up="Update Place Set DescripPlace='"+f+"' where numPlace="+numP+" and IdParking="+idP+" ";
                        st.executeUpdate(up);
                        
                        
                }

            } catch (ClassNotFoundException | SQLException ex) {
               JOptionPane.showMessageDialog(this,ex.getMessage());
            }

        }
    }//GEN-LAST:event_jButton5ActionPerformed
    /**/
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> NamePark;
    private javax.swing.JTextField NomVeh;
    private javax.swing.JComboBox<String> NumEtage;
    private javax.swing.JComboBox<String> NumPlace;
    private javax.swing.JTextField NumVeh;
    private javax.swing.JTextField TimeDEB;
    private javax.swing.JTextField TimeFin;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea2;
    private org.joda.time.TimeOfDay timeOfDay1;
    public final javax.swing.JLabel user = new javax.swing.JLabel();
    public final javax.swing.JLabel user1 = new javax.swing.JLabel();
    // End of variables declaration//GEN-END:variables
}
