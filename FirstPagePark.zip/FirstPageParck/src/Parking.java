/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lara
 */
public class Parking {
    private int id;
    private String name;
    private int nb_etage;
    private int nb_Place;
    private String Adresse;

    public Parking(int id, String name, int nb_etage, int nb_Place, String Adresse) {
        this.id = id;
        this.name = name;
        this.nb_etage = nb_etage;
        this.nb_Place = nb_Place;
        this.Adresse = Adresse;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getNb_etage() {
        return nb_etage;
    }

    public int getNb_Place() {
        return nb_Place;
    }

    public String getAdresse() {
        return Adresse;
    }
    
    
    
}
